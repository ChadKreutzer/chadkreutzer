module.exports = {
    cookieSecret: 'find sort corn crop',
    gmail: {
        user: 'kanthalion@gmail.com',
        password: 'My Google password!'
    }
};